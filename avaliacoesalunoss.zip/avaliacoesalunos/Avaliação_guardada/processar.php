<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

require_once __DIR__ . '/vendor/Exception.php';
require_once __DIR__ . '/vendor/PHPMailer.php';
require_once __DIR__ . '/vendor/SMTP.php';

// --- CONFIGURAÇÃO DE EMAIL (SMTP) ---
// Conta que vai enviar os emails (remetente)
// Se for Gmail: smtp.gmail.com | Outlook: smtp.office365.com
define('SMTP_HOST', 'smtp.gmail.com');
define('SMTP_PORT', 465);
define('SMTP_USER', 'diana17faria@gmail.com');
define('SMTP_PASS', 'kdza mhjq kotg bcar');
define('SMTP_FROM', 'diana17faria@gmail.com');
define('SMTP_FROM_NAME', 'Avaliações Escolares');
// ------------------------------------

$host = "localhost";
$user = "root";
$pass = "";
$db   = "escola";

$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
    die("Falha na ligação: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    
    $nome_aluno    = $_POST['nome_aluno'];
    $numero_aluno  = intval($_POST['numero_aluno']);
    $id_disciplina = intval($_POST['id_disciplina']);
    $nota          = floatval($_POST['nota']);
    $observacoes   = $_POST['observacoes'];
    $email         = $_POST['email'] ?? '';

    // Query para descobrir o nome real da disciplina associada ao ID enviado
    $nome_disciplina = "Desconhecida";
    $res_disc = $conn->query("SELECT nome FROM disciplinas WHERE id = $id_disciplina");
    if($res_disc && $row = $res_disc->fetch_assoc()) {
        $nome_disciplina = $row['nome'];
    }

    $obs_escaped = $conn->real_escape_string($observacoes);
    $sql = "INSERT INTO notas (nota, observacoes, disciplinas, numero_aluno) 
            VALUES ($nota, '$obs_escaped', $id_disciplina, $numero_aluno)";
    $conn->query($sql);

    echo "<div style='font-family: Arial; margin: 40px; padding: 20px; border: 1px solid #ccc; background: #fff;'>";
    echo "<h2 style='color: #27ae60;'>Avaliação Registada com Sucesso!</h2>";
    echo "<hr>";
    echo "<p><strong>Aluno:</strong> " . htmlspecialchars($nome_aluno) . " </p>";
    echo "<p><strong>Número de Aluno:</strong> " . $numero_aluno . " <em>(Verificado automaticamente)</em></p>";
    echo "<p><strong>Disciplina:</strong> " . htmlspecialchars($nome_disciplina) . " (ID: $id_disciplina)</p>";
    echo "<p><strong>Nota Atribuída:</strong> " . number_format($nota, 2) . "</p>";
    echo "<p><strong>Observações de Desempenho:</strong><br>" . nl2br(htmlspecialchars($observacoes)) . "</p>";
    
    if (!empty($email) && filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $email_configurado = (SMTP_USER !== 'teuemail@gmail.com' && SMTP_USER !== '');
        if (!$email_configurado) {
            echo "<p style='color: #f39c12;'><strong>Email não foi enviado: configura o SMTP no processar.php (linhas 14-17) quando decidires.</strong></p>";
        } else {
            $cor_assunto = ($nota < 9.5) ? '#e74c3c' : (($nota < 13.5) ? '#f39c12' : '#27ae60');
            $status_nota = ($nota < 9.5) ? 'Negativa' : (($nota < 13.5) ? 'Suficiente' : 'Positiva');
            $obs_html = !empty($observacoes) ? nl2br(htmlspecialchars($observacoes)) : '<em>Sem observações</em>';

            $mensagem_html = "
            <html>
            <head><meta charset='UTF-8'><title>Avaliação Escolar</title></head>
            <body style='font-family: Arial, sans-serif; padding: 30px;'>
                <p>Olá!</p>
                <p>Esperamos que esteja tudo bem por aí.</p>
                <p>Segue em anexo o documento com as notas dos alunos para vossa consulta.</p>
                <br>
                <p>Atenciosamente,</p>
                <p>Gestão Escolar</p>
            </body>
            </html>";

            $mail = new PHPMailer(true);
            try {
                $mail->isSMTP();
                $mail->Host       = SMTP_HOST;
                $mail->SMTPAuth   = true;
                $mail->Username   = SMTP_USER;
                $mail->Password   = SMTP_PASS;
                $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;
                $mail->Port       = SMTP_PORT;

                $mail->setFrom(SMTP_FROM, SMTP_FROM_NAME);
                $mail->addAddress($email);
                $mail->isHTML(true);
                $mail->CharSet = 'UTF-8';
                $mail->Subject = "Avaliação - " . htmlspecialchars($nome_aluno);
                $mail->Body    = $mensagem_html;

                $mail->send();
                $email_status = "sucesso";
            } catch (Exception $e) {
                $email_status = "erro: " . $mail->ErrorInfo;
            }

            if ($email_status === "sucesso") {
                echo "<p style='color: #27ae60;'><strong>Email enviado com sucesso para " . htmlspecialchars($email) . "!</strong></p>";
            } else {
                echo "<p style='color: #e74c3c;'><strong>Erro ao enviar email: " . htmlspecialchars($email_status) . "</strong></p>";
            }
        }
    } elseif (!empty($email)) {
        echo "<p style='color: #e74c3c;'><strong>Email inválido. A avaliação foi guardada mas não foi enviado nenhum email.</strong></p>";
    }

    echo "<br><a href='index.html' style='color: #3498db;'>Inserir nova avaliação</a>";
    echo "</div>";
}

$conn->close();
?>