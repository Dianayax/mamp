<?php
// 1. Configuração da ligação à Base de Dados
$host = "localhost";
$user = "root";
$pass = "";
$db   = "escola"; // Nome da tua base de dados

$conn = new mysqli($host, $user, $pass, $db);

// Verifica se a ligação falhou
if ($conn->connect_error) {
    die("Falha na ligação com a Base de Dados: " . $conn->connect_error);
}

// 2. Verificar se os dados foram enviados pelo formulário via POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    
    // Capturar os dados enviados pelo formulário
    $nome_aluno    = $_POST['nome_aluno'];
    $numero_aluno  = intval($_POST['numero_aluno']);
    $id_disciplina = intval($_POST['id_disciplina']);
    $nota          = floatval($_POST['nota']);
    $observacoes   = $_POST['observacoes']; // Guardado temporariamente ou enviado para sumário

    // 3. Criar o comando SQL para INSERIR os dados na tabela 'notas'
    // Mapeamento correto com as colunas da tua BD: nota, disciplinas, numero_aluno
    $obs_escaped = $conn->real_escape_string($observacoes);
    $sql = "INSERT INTO `notas` (`nota`, `observacoes`, `disciplinas`, `numero_aluno`) 
            VALUES ($nota, '$obs_escaped', $id_disciplina, $numero_aluno)";

    // 4. Executar o comando no MySQL e validar o sucesso
    if ($conn->query($sql) === TRUE) {
        
        // Query extra apenas para descobrir o nome em texto da disciplina para o relatório
        $nome_disciplina = "Desconhecida";
        $res_disc = $conn->query("SELECT nome FROM disciplinas WHERE id = $id_disciplina");
        if($res_disc && $row = $res_disc->fetch_assoc()) {
            $nome_disciplina = $row['nome'];
        }

        // Interface visual de Sucesso
        echo "<div style='font-family: Arial, sans-serif; margin: 40px; padding: 25px; border: 2px solid #27ae60; background-color: #ebf7ee; border-radius: 8px; max-width: 600px;'>";
        echo "<h2 style='color: #27ae60; margin-top: 0;'>✓ Avaliação Gravada com Sucesso!</h2>";
        echo "<p style='color: #27ae60; font-size: 14px;'>Os dados já foram inseridos de forma permanente na tabela <strong>notas</strong> do MySQL.</p>";
        echo "<hr style='border: 0; border-top: 1px solid #27ae60; margin: 15px 0;'>";
        echo "<p><strong>Aluno:</strong> " . htmlspecialchars($nome_aluno) . " </p>";
        echo "<p><strong>Número do Aluno:</strong> " . $numero_aluno . "</p>";
        echo "<p><strong>Disciplina:</strong> " . htmlspecialchars($nome_disciplina) . " (ID: $id_disciplina)</p>";
        echo "<p><strong>Nota Guardada:</strong> " . number_format($nota, 2) . "</p>";
        
        if(!empty($observacoes)) {
            echo "<p><strong>Observações de Desempenho:</strong><br><span style='color: #555; font-style: italic;'>" . nl2br(htmlspecialchars($observacoes)) . "</span></p>";
        }
        
        echo "<br><a href='index.php' style='display: inline-block; padding: 10px 15px; background-color: #27ae60; color: white; text-decoration: none; border-radius: 4px; font-weight: bold;'>Inserir Nova Avaliação</a>";
        echo "</div>";

    } else {
        // Se houver algum erro de SQL (ex: falta de chave estrangeira, coluna errada)
        echo "<div style='font-family: Arial, sans-serif; margin: 40px; padding: 25px; border: 2px solid #c0392b; background-color: #f9ebea; border-radius: 8px; max-width: 600px;'>";
        echo "<h2 style='color: #c0392b; margin-top: 0;'>❌ Erro ao Gravar Avaliação</h2>";
        echo "<p>Não foi possível guardar o registo na base de dados.</p>";
        echo "<p><strong>Detalhe do Erro:</strong> " . $conn->error . "</p>";
        echo "<br><a href='index.php' style='color: #c0392b;'>Voltar e tentar novamente</a>";
        echo "</div>";
    }
}

// Fechar a ligação à base de dados
$conn->close();
?>