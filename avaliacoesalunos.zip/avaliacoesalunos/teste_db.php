<?php
echo "<h2>Teste de Ligação à Base de Dados</h2>";

$host = "localhost";
$user = "root";
$pass = "";
$db   = "escola";

$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
    echo "<p style='color:red;'>❌ Falha na ligação: " . $conn->connect_error . "</p>";
} else {
    echo "<p style='color:green;'>✅ Ligação estabelecida com sucesso!</p>";

    $res = $conn->query("SELECT DATABASE() AS db, VERSION() AS ver");
    $row = $res->fetch_assoc();
    echo "<p>Base de dados: <strong>" . $row['db'] . "</strong></p>";
    echo "<p>Versão MySQL: <strong>" . $row['ver'] . "</strong></p>";

    $res2 = $conn->query("SHOW TABLES");
    echo "<p>Tabelas existentes:</p><ul>";
    $count = 0;
    while ($t = $res2->fetch_array()) {
        echo "<li>" . $t[0] . "</li>";
        $count++;
    }
    echo "</ul>";
    echo "<p>Total de tabelas: $count</p>";

    $conn->close();
}
?>
<p><a href='index.html'>Voltar</a></p>
