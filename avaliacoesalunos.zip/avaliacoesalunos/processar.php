<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

require_once __DIR__ . '/vendor/Exception.php';
require_once __DIR__ . '/vendor/PHPMailer.php';
require_once __DIR__ . '/vendor/SMTP.php';

// --- CONFIGURAÇÃO DE EMAIL (SMTP) ---
// Conta que vai enviar os emails (remetente)
// Se for Gmail: smtp.gmail.com | Outlook: smtp.office365.com
define('SMTP_HOST', 'smtp.gmail.com');
define('SMTP_PORT', 587);
define('SMTP_USER', 'diana17faria@gmail.com');
define('SMTP_PASS', 'kdza mhjq kotg bcar');
define('SMTP_FROM', 'diana17faria@gmail.com');
define('SMTP_FROM_NAME', 'Avaliações Escolares');
// ------------------------------------

$host = "localhost";
$user = "root";
$pass = "";
$db   = "escola";

$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
    die("Falha na ligação: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    
    $nome_aluno    = $_POST['nome_aluno'];
    $numero_aluno  = intval($_POST['numero_aluno']);
    $id_disciplina = intval($_POST['id_disciplina']);
    $nota          = floatval($_POST['nota']);
    $observacoes   = $_POST['observacoes'];
    $email         = $_POST['email'] ?? '';

    // Query para descobrir o nome real da disciplina associada ao ID enviado
    $nome_disciplina = "Desconhecida";
    $res_disc = $conn->query("SELECT nome FROM disciplinas WHERE id = $id_disciplina");
    if($res_disc && $row = $res_disc->fetch_assoc()) {
        $nome_disciplina = $row['nome'];
    }

    $obs_escaped = $conn->real_escape_string($observacoes);
    $sql = "INSERT INTO notas (nota, observacoes, disciplinas, numero_aluno) 
            VALUES ($nota, '$obs_escaped', $id_disciplina, $numero_aluno)";
    $conn->query($sql);

    echo "<div style='font-family: Arial; margin: 40px; padding: 20px; border: 1px solid #ccc; background: #fff;'>";
    echo "<h2 style='color: #27ae60;'>Avaliação Registada com Sucesso!</h2>";
    echo "<hr>";
    echo "<p><strong>Aluno:</strong> " . htmlspecialchars($nome_aluno) . " </p>";
    echo "<p><strong>Número de Aluno:</strong> " . $numero_aluno . " <em>(Verificado automaticamente)</em></p>";
    echo "<p><strong>Disciplina:</strong> " . htmlspecialchars($nome_disciplina) . " (ID: $id_disciplina)</p>";
    echo "<p><strong>Nota Atribuída:</strong> " . number_format($nota, 2) . "</p>";
    echo "<p><strong>Observações de Desempenho:</strong><br>" . nl2br(htmlspecialchars($observacoes)) . "</p>";
    
    if (!empty($email) && filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $email_configurado = (SMTP_USER !== 'teuemail@gmail.com' && SMTP_USER !== '');
        if (!$email_configurado) {
            echo "<p style='color: #f39c12;'><strong>Email não foi enviado: configura o SMTP no processar.php (linhas 14-17) quando decidires.</strong></p>";
        } else {
            $cor_assunto = ($nota < 9.5) ? '#e74c3c' : (($nota < 13.5) ? '#f39c12' : '#27ae60');
            $status_nota = ($nota < 9.5) ? 'Negativa' : (($nota < 13.5) ? 'Suficiente' : 'Positiva');
            $obs_html = !empty($observacoes) ? nl2br(htmlspecialchars($observacoes)) : '<em>Sem observações</em>';

            $mensagem_html = "
            <html>
            <head><meta charset='UTF-8'><title>Avaliação Escolar</title></head>
            <body style='font-family: Arial, sans-serif; background: #f4f4f4; padding: 30px;'>
                <div style='max-width: 500px; margin: 0 auto; background: #fff; border-radius: 8px; overflow: hidden; box-shadow: 0 2px 8px rgba(0,0,0,0.1);'>
                    <div style='background: #40997d; padding: 20px; text-align: center;'>
                        <h2 style='color: #fff; margin: 0;'>Avaliação Escolar</h2>
                    </div>
                    <div style='padding: 25px;'>
                        <table style='width:100%; border-collapse: collapse; font-size: 14px;'>
                            <tr><td style='padding: 8px; color: #555; font-weight: bold;'>Aluno</td><td style='padding: 8px;'>" . htmlspecialchars($nome_aluno) . "</td></tr>
                            <tr style='background: #f9f9f9;'><td style='padding: 8px; color: #555; font-weight: bold;'>Número</td><td style='padding: 8px;'>$numero_aluno</td></tr>
                            <tr><td style='padding: 8px; color: #555; font-weight: bold;'>Disciplina</td><td style='padding: 8px;'>" . htmlspecialchars($nome_disciplina) . "</td></tr>
                            <tr style='background: #f9f9f9;'><td style='padding: 8px; color: #555; font-weight: bold;'>Nota</td><td style='padding: 8px; font-weight: bold; color: $cor_assunto;'>" . number_format($nota, 2) . " ($status_nota)</td></tr>
                            <tr><td style='padding: 8px; color: #555; font-weight: bold; vertical-align: top;'>Observações</td><td style='padding: 8px;'>$obs_html</td></tr>
                        </table>
                    </div>
                    <div style='background: #eee; padding: 12px; text-align: center; font-size: 12px; color: #888;'>
                        Sistema de Avaliações Escolares
                    </div>
                </div>
            </body>
            </html>";

            $mail = new PHPMailer(true);
            try {
                $mail->isSMTP();
                $mail->Host       = SMTP_HOST;
                $mail->SMTPAuth   = true;
                $mail->Username   = SMTP_USER;
                $mail->Password   = SMTP_PASS;
                $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
                $mail->Port       = SMTP_PORT;

                $mail->setFrom(SMTP_FROM, SMTP_FROM_NAME);
                $mail->addAddress($email);
                $mail->isHTML(true);
                $mail->CharSet = 'UTF-8';
                $mail->Subject = "Avaliação - " . htmlspecialchars($nome_aluno);
                $mail->Body    = $mensagem_html;

                $mail->send();
                $email_status = "sucesso";
            } catch (Exception $e) {
                $email_status = "erro: " . $mail->ErrorInfo;
            }

            if ($email_status === "sucesso") {
                echo "<p style='color: #27ae60;'><strong>Email enviado com sucesso para " . htmlspecialchars($email) . "!</strong></p>";
            } else {
                echo "<p style='color: #e74c3c;'><strong>Erro ao enviar email: " . htmlspecialchars($email_status) . "</strong></p>";
            }
        }
    } elseif (!empty($email)) {
        echo "<p style='color: #e74c3c;'><strong>Email inválido. A avaliação foi guardada mas não foi enviado nenhum email.</strong></p>";
    }

    echo "<br><a href='index.html' style='color: #3498db;'>Inserir nova avaliação</a>";
    echo "</div>";
}

$conn->close();
?>