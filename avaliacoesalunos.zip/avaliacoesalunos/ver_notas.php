<?php
$host = "localhost";
$user = "root";
$pass = "";
$db   = "escola";

$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
    die("Falha na ligação: " . $conn->connect_error);
}

$filtro_aluno = isset($_GET['aluno']) ? intval($_GET['aluno']) : 0;

$sql = "SELECT n.id, n.nota, n.observacoes,
               a.nome AS nome_aluno, a.numero_aluno,
               d.nome AS nome_disciplina
        FROM notas n
        LEFT JOIN alunos a ON n.numero_aluno = a.numero_aluno
        LEFT JOIN disciplinas d ON n.disciplinas = d.id";

if ($filtro_aluno > 0) {
    $sql .= " WHERE n.numero_aluno = $filtro_aluno";
}

$sql .= " ORDER BY n.id DESC";

$resultado = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="pt-PT">
<head>
    <meta charset="UTF-8">
    <title>Notas Registadas</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: Arial, sans-serif;
            background-color: #40997d;
            padding: 30px;
        }
        .container {
            max-width: 1100px;
            margin: 0 auto;
            background: #fff;
            border-radius: 10px;
            padding: 25px 30px;
            box-shadow: 0 4px 10px rgba(0,0,0,0.1);
        }
        h1 {
            text-align: center;
            color: #2c3e50;
            margin-bottom: 8px;
        }
        .subtitulo {
            text-align: center;
            color: #666;
            margin-bottom: 25px;
            font-size: 14px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            font-size: 14px;
        }
        thead {
            background-color: #27ae60;
            color: #fff;
        }
        thead th {
            padding: 12px 10px;
            text-align: left;
            font-weight: bold;
        }
        tbody tr {
            border-bottom: 1px solid #e0e0e0;
        }
        tbody tr:hover {
            background-color: #f5f5f5;
        }
        tbody td {
            padding: 10px;
            vertical-align: middle;
        }
        .nota {
            font-weight: bold;
            color: #27ae60;
            text-align: center;
        }
        .nota-baixa {
            color: #e74c3c;
        }
        .nota-media {
            color: #f39c12;
        }
        .sem-registo {
            text-align: center;
            color: #888;
            font-style: italic;
            padding: 40px;
        }
        .acoes {
            text-align: center;
            margin-top: 25px;
        }
        .acoes a {
            display: inline-block;
            background: #27ae60;
            color: #fff;
            padding: 10px 20px;
            text-decoration: none;
            border-radius: 5px;
            font-weight: bold;
        }
        .acoes a:hover {
            background: #219653;
        }
        .n-aluno {
            font-weight: bold;
            color: #555;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Notas Registadas</h1>
        <p class="subtitulo">Consultar todas as avaliações inseridas na base de dados</p>

        <?php if ($resultado && $resultado->num_rows > 0): ?>
        <table>
            <thead>
                <tr>
                    <th>Nº</th>
                    <th>Nome do Aluno</th>
                    <th>Disciplina</th>
                    <th>Nota</th>
                    <th>Observações</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($linha = $resultado->fetch_assoc()):
                    $nota = floatval($linha['nota']);
                    $classe_nota = 'nota';
                    if ($nota < 9.5) $classe_nota .= ' nota-baixa';
                    elseif ($nota < 13.5) $classe_nota .= ' nota-media';
                ?>
                <tr>
                    <td class="n-aluno"><?= htmlspecialchars($linha['numero_aluno']) ?></td>
                    <td><?= htmlspecialchars($linha['nome_aluno'] ?? 'Não encontrado') ?></td>
                    <td><?= htmlspecialchars($linha['nome_disciplina'] ?? 'Não encontrada') ?></td>
                    <td class="<?= $classe_nota ?>"><?= number_format($nota, 2) ?></td>
                    <td><?= htmlspecialchars($linha['observacoes'] ?? '') ?></td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
        <?php else: ?>
        <p class="sem-registo">Ainda não existem notas registadas na base de dados.</p>
        <?php endif; ?>

        <div class="acoes">
            <a href="index.html">Voltar ao Início</a>
        </div>
    </div>
</body>
</html>

<?php $conn->close(); ?>
